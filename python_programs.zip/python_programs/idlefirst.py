#idle first program of IF/ELSE program
"""this is used for commenting in multiple lines like
comment 1
comment 2
comment3"""

a=2
if(a==0):
    print("Its even")
else:
    print("its odd")
